
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <sys/mman.h>
#include <stdbool.h>
#include "mmap_hw_regs.h"
//#include "led.h"
#include "dipsw_pio.h"
//#include "key_pio.h"
//#include "pio_reg_in.h"
//#include "pio_reg_out.h"
//#include "pio_reg_inout.h"
//#include "led_gpio.h"
//#include "key_gpio.h"
#include "driver.h"


//void test_all();


//unsigned int DRIVER_read_pio_reg_inout();
//void write_pi_reg_inout( unsigned int pio_reg_inout );
void write_pio_reg_out( unsigned int pio_reg_out );
//unsigned int DRIVER_read_pio_reg_in();
void DRIVER_out_write_data( unsigned int data );	


int main(int argc, char **argv) {
	MMAP_open();
	/* DIPSW_setup();
	KEY_PIO_setup();
	KEY_gpio_setup(); */
	DRIVER_setup();
	// faut pas mettre le mmap_close à la fin du code ?
	char choice;
	do{
	unsigned int degree = 0; //, value
    printf("Enter degree value (0-180): ");
    scanf("%d", &degree);

	DRIVER_out_write_data(degree);

    printf("Do you want to enter another angle? (y/n): ");
    scanf(" %c", &choice);
    } while (choice == 'y' || choice == 'Y');
	
	MMAP_close();
	
    return 0;
}