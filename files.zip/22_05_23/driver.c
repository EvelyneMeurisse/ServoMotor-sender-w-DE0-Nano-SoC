
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
//#include <time.h>
//#include <sys/mman.h>
//#include <stdbool.h>
//#include "mmap_hw_regs.h"
//#include "led.h"
//#include "dipsw_pio.h"
//#include "key_pio.h"
//#include "pio_reg_in.h"
#include "pio_reg_out.h"
//#include "pio_reg_inout.h"
//#include "led_gpio.h"
//#include "key_gpio.h"
#include "driver.h"



void write_pio_reg_out( unsigned int pio_reg_out );

void DRIVER_setup();

void DRIVER_setup() {
	PIO_REG_OUT_setup();
}

void write_pio_reg_out( unsigned int pio_reg_out ) {
	printf ("writing pio_reg_out\t%s\n", PIO_REG_OUT_binary_string( pio_reg_out ) );
	PIO_REG_OUT_write( pio_reg_out );
	pio_reg_out = PIO_REG_OUT_read();
	printf ("reading pio_reg_out\t%s\n", PIO_REG_OUT_binary_string( pio_reg_out ) );		
}

void DRIVER_out_write_data( unsigned int degree ) {
	unsigned int data;
	data = (degree * 255) / 180; //0 - 255 (sous 8 bits car unsigned int)
	printf("writing data\r\n");
	write_pio_reg_out( data );
}

