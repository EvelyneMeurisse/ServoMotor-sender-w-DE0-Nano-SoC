// driver.h 
#ifndef DRIVER_H_
#define DRIVER_H_
 
void DRIVER_setup();
void DRIVER_out_write_data( unsigned int data );
unsigned int DRIVER_read_pio_reg_in();
#endif /*DRIVER_H_*/

 
